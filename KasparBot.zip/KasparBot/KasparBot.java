import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;

// This class runs the bidding bot and decides how much to bid each round.
public class KasparBot {

    // This is the ad category the bot specializes in.
    public static final String CATEGORY = "Finance";

    // Index of the Finance category inside the category tables.
    private static final int FINANCE_INDEX = 8;

    // Default amount of ebucks if no command line argument is provided.
    private static final long DEFAULT_BUDGET = 10000000L;

    // Estimated number of important rounds used to control spending pace.
    private static final int EXPECTED_ROUNDS = 100000;

    // Spending limits used to avoid finishing too far below the required spend level.
    private static final double HARD_SPEND_FLOOR = 0.30;
    private static final double SOFT_SPEND_FLOOR = 0.302;

    // Earlier viewer interests are treated as more important than later ones.
    private static final double[] INTEREST_POSITION_WEIGHTS = {
            1.0, 0.44, 0.225
    };

    // Estimated match strength between viewer interests and video categories.
    private static final double[][] CATEGORY_MATCH = {
            {1.0, 0.28, 0.2, 0.1, 0.25, 0.4, 0.45, 0.1, 0.19},
            {0.28, 1.0, 0.25, 0.3, 0.35, 0.19, 0.1, 0.28, 0.2},
            {0.2, 0.25, 1.0, 0.3, 0.5, 0.28, 0.28, 0.3, 0.19},
            {0.1, 0.3, 0.3, 1.0, 0.28, 0.2, 0.25, 0.5, 0.25},
            {0.25, 0.35, 0.5, 0.28, 1.0, 0.3, 0.1, 0.19, 0.1},
            {0.4, 0.19, 0.28, 0.2, 0.3, 1.0, 0.5, 0.25, 0.19},
            {0.45, 0.1, 0.28, 0.25, 0.1, 0.5, 1.0, 0.35, 0.1},
            {0.1, 0.28, 0.3, 0.5, 0.19, 0.25, 0.35, 1.0, 0.28},
            {0.19, 0.2, 0.19, 0.25, 0.1, 0.19, 0.1, 0.28, 1.0}
    };

    // Estimated age and gender preference table for male viewers.
    private static final double[][] AGE_WEIGHT_MALE = {
            {0.45, 0.4, 0.28, 0.1, 0.6, 0.25, 0.05, 0.05, 0.05},
            {0.5, 0.5, 0.05, 0.2, 0.55, 0.2, 0.05, 0.28, 0.3},
            {0.3, 0.45, 0.25, 0.4, 0.35, 0.1, 0.05, 0.25, 0.45},
            {0.2, 0.4, 0.45, 0.5, 0.2, 0.05, 0.05, 0.3, 0.5},
            {0.28, 0.3, 0.25, 0.45, 0.1, 0.05, 0.05, 0.35, 0.4},
            {0.28, 0.2, 0.2, 0.35, 0.05, 0.05, 0.05, 0.4, 0.3}
    };

    // Estimated age and gender preference table for female viewers.
    private static final double[][] AGE_WEIGHT_FEMALE = {
            {0.5, 0.28, 0.28, 0.28, 0.3, 0.5, 0.45, 0.28, 0.19},
            {0.5, 0.28, 0.19, 0.2, 0.2, 0.4, 0.55, 0.25, 0.1},
            {0.3, 0.28, 0.4, 0.3, 0.28, 0.25, 0.45, 0.4, 0.3},
            {0.2, 0.1, 0.5, 0.4, 0.1, 0.28, 0.35, 0.5, 0.3},
            {0.28, 0.1, 0.3, 0.4, 0.19, 0.1, 0.25, 0.5, 0.25},
            {0.28, 0.1, 0.25, 0.3, 0.19, 0.1, 0.2, 0.5, 0.2}
    };

    // Allows other programs to access the bot category if the class is imported.
    public String getCategory() {
        return CATEGORY;
    }

    // Static access to the category for harness integrations.
    public static String getBotCategory() {
        return CATEGORY;
    }

    // Main entry point that communicates with the auction harness.
    public static void main(String[] args) throws IOException {
        long totalBudget = readBudget(args);
        long remainingBudget = totalBudget;
        long spentBudget = 0L;

        int roundsPlayed = 0;
        int totalWins = 0;
        int winsSinceSummary = 0;
        int roundsSinceWin = 0;

        double aggression = 1.0;
        double recentEfficiency = 0.59;
        double averageWinCost = 10.0;
        double recentAverageWinCost = 10.0;

        BufferedReader in = new BufferedReader(
                new InputStreamReader(System.in, StandardCharsets.ISO_8859_1));

        PrintWriter out = new PrintWriter(
                new OutputStreamWriter(System.out, StandardCharsets.ISO_8859_1), true);

        // First output line must be the chosen advertisement category.
        out.println(CATEGORY);
        out.flush();

        String line;

        // Continue processing auction rounds until the input ends.
        while ((line = in.readLine()) != null) {
            line = line.trim();

            if (line.isEmpty()) {
                continue;
            }

            char firstChar = line.charAt(0);

            // Handle protocol lines that describe previous round results.
            switch (firstChar) {
                case 'W':
                    if (isProtocolLine(line)) {
                        long winCost = Math.min(extractWinCost(line), remainingBudget);
                        remainingBudget -= winCost;
                        spentBudget += winCost;
                        totalWins++;
                        winsSinceSummary++;
                        roundsSinceWin = 0;

                        if (totalWins > 0 && spentBudget > 0L) {
                            averageWinCost = (double) spentBudget / (double) totalWins;
                        }

                        continue;
                    }
                    break;

                case 'L':
                    if (isProtocolLine(line)) {
                        roundsSinceWin++;
                        continue;
                    }
                    break;

                case 'S':
                    if (isProtocolLine(line)) {
                        SummaryData summary = parseSummary(line);

                        if (summary.spent > 0L) {
                            recentEfficiency = (double) summary.points / (double) summary.spent;

                            if (winsSinceSummary > 0) {
                                recentAverageWinCost =
                                        (double) summary.spent / (double) winsSinceSummary;
                            }
                        }

                        aggression = adjustAggression(
                                summary,
                                aggression,
                                spentBudget,
                                totalBudget
                        );

                        winsSinceSummary = 0;
                        continue;
                    }
                    break;

                default:
                    break;
            }

            roundsPlayed++;

            // Parse the auction round information.
            AuctionRound round = parseAuctionRound(line);

            // Evaluate how valuable this advertisement opportunity is.
            RoundScore score = evaluateRound(round);

            // Decide the bidding range for this round.
            BidRange bid = chooseBid(
                    score,
                    remainingBudget,
                    spentBudget,
                    totalBudget,
                    roundsPlayed,
                    roundsSinceWin,
                    aggression,
                    recentEfficiency,
                    averageWinCost,
                    recentAverageWinCost
            );

            // Output the start bid and maximum bid.
            out.println(bid.startBid + " " + bid.maxBid);
            out.flush();
        }
    }

    // Converts the incoming text line into structured auction data.
    private static AuctionRound parseAuctionRound(String line) {
        AuctionRound round = new AuctionRound();
        String[] fields = line.split(",");

        for (String field : fields) {
            String[] pair = field.split("=", 2);

            if (pair.length != 2) {
                continue;
            }

            String key = pair[0].trim();
            String value = pair[1].trim();

            switch (key) {
                case "video.category":
                    round.videoCategory = value;
                    break;

                case "video.viewCount":
                    round.videoViewCount = parseLong(value);
                    break;

                case "video.commentCount":
                    round.videoCommentCount = parseLong(value);
                    break;

                case "viewer.subscribed":
                    round.viewerSubscribed = value.equalsIgnoreCase("Y");
                    break;

                case "viewer.age":
                    round.viewerAge = value;
                    break;

                case "viewer.gender":
                    round.viewerGender = value;
                    break;

                case "viewer.interests":
                    round.viewerInterests = value;
                    break;

                default:
                    break;
            }
        }

        return round;
    }

    // Evaluates the quality of the auction opportunity and returns a detailed score.
    private static RoundScore evaluateRound(AuctionRound round) {
        int videoCategoryIndex = categoryIndex(round.videoCategory);

        if (videoCategoryIndex < 0) {
            return RoundScore.EMPTY;
        }

        double viewerWeight = round.viewerSubscribed ? 0.17 : 0.0;
        viewerWeight += ageCategoryWeight(
                round.viewerAge,
                round.viewerGender,
                videoCategoryIndex
        );

        int financeInterestPosition = -1;

        if (round.viewerInterests != null && !round.viewerInterests.isEmpty()) {
            String[] interests = round.viewerInterests.split(";");

            for (int i = 0; i < interests.length; i++) {
                int interestIndex = categoryIndex(interests[i].trim());

                if (interestIndex < 0) {
                    continue;
                }

                if (interestIndex == FINANCE_INDEX && financeInterestPosition < 0) {
                    financeInterestPosition = i;
                }

                if (i < INTEREST_POSITION_WEIGHTS.length) {
                    viewerWeight +=
                            INTEREST_POSITION_WEIGHTS[i]
                                    * CATEGORY_MATCH[interestIndex][videoCategoryIndex];
                }
            }
        }

        double financeMatch = Math.max(
                0.161,
                CATEGORY_MATCH[FINANCE_INDEX][videoCategoryIndex]
        );

        double commentFactor = 1.0 + (
                9999.0 + 15.0 * (double) round.videoCommentCount
        ) / (
                9999.0 + (double) round.videoViewCount
        );

        int baseValue = baseValueForViews(round.videoViewCount);

        int estimatedValue = (int) Math.ceil(
                baseValue * commentFactor * viewerWeight * financeMatch
        );

        boolean financeVideo = videoCategoryIndex == FINANCE_INDEX;
        boolean directFinance = financeVideo || financeInterestPosition == 0;

        return new RoundScore(
                estimatedValue,
                financeInterestPosition,
                financeVideo,
                directFinance,
                round.viewerSubscribed
        );
    }

    // Determines the bid range based on score, budget, and spending pace.
    private static BidRange chooseBid(
            RoundScore score,
            long remainingBudget,
            long spentBudget,
            long totalBudget,
            int roundsPlayed,
            int roundsSinceWin,
            double aggression,
            double recentEfficiency,
            double averageWinCost,
            double recentAverageWinCost
    ) {
        if (remainingBudget <= 0L || score.estimatedValue <= 0) {
            return BidRange.ZERO;
        }

        double progress = Math.min(1.2, (double) roundsPlayed / (double) EXPECTED_ROUNDS);
        double spentRatio = totalBudget <= 0L ? 0.0 : (double) spentBudget / (double) totalBudget;
        double targetRatio = targetSpend(progress);
        double spendingPressure = targetRatio - spentRatio;
        boolean belowSpendFloor = spentRatio < SOFT_SPEND_FLOOR;

        double marketCost = recentAverageWinCost > 0.0
                ? recentAverageWinCost
                : averageWinCost;

        if (marketCost < 1.0) {
            marketCost = 10.0;
        }

        double valuePerCost = score.estimatedValue / marketCost;

        int minimumValue = 9;

        if (spendingPressure > 0.12 || (progress > 0.92 && spentRatio < 0.29)) {
            minimumValue = 2;
        } else if (spendingPressure > 0.09 || (progress > 0.85 && spentRatio < 0.27)) {
            minimumValue = 3;
        } else if (spendingPressure > 0.08 || (roundsSinceWin > 2500 && belowSpendFloor)) {
            minimumValue = 4;
        } else if (spendingPressure > 0.06 || roundsSinceWin > 1500) {
            minimumValue = 5;
        } else if (spendingPressure > 0.03) {
            minimumValue = 6;
        } else if (spendingPressure > 0.01) {
            minimumValue = 7;
        }

        if (progress > 0.93 && spentRatio < HARD_SPEND_FLOOR) {
            minimumValue = Math.min(minimumValue, 2);
        } else if (progress > 0.85 && spentRatio < HARD_SPEND_FLOOR) {
            minimumValue = Math.min(minimumValue, 4);
        }

        if (valuePerCost < 0.65 && spendingPressure <= 0.02 && !belowSpendFloor) {
            minimumValue = Math.max(minimumValue, 10);
        }

        if (spentRatio >= SOFT_SPEND_FLOOR) {
            if (score.estimatedValue < 14) {
                return BidRange.ZERO;
            }

            if (!score.directFinance && score.estimatedValue < 18) {
                return BidRange.ZERO;
            }

            if (score.estimatedValue < 18 && valuePerCost < 1.35) {
                return BidRange.ZERO;
            }

            minimumValue = Math.max(minimumValue, 15);
        }

        if (score.estimatedValue < minimumValue) {
            return BidRange.ZERO;
        }

        double bidBoost = 1.0;

        if (score.financeVideo) {
            bidBoost += 0.06;
        }

        if (score.financeInterestPosition == 0) {
            bidBoost += 0.12;
        } else if (score.financeInterestPosition == 1) {
            bidBoost += 0.06;
        } else if (score.financeInterestPosition == 2) {
            bidBoost += 0.03;
        }

        if (score.viewerSubscribed) {
            bidBoost += 0.04;
        }

        if (recentEfficiency > 0.68 && score.estimatedValue >= 12) {
            bidBoost += 0.05;
        } else if (recentEfficiency < 0.48 && score.estimatedValue < 18) {
            bidBoost -= 0.05;
        }

        if (spendingPressure > 0.12) {
            bidBoost += 0.18;
        } else if (spendingPressure > 0.08) {
            bidBoost += 0.12;
        } else if (spendingPressure > 0.04) {
            bidBoost += 0.05;
        }

        if (!belowSpendFloor) {
            bidBoost -= 0.08;
        }

        double maxBidScale = 1.18 + 0.025 * Math.min(score.estimatedValue, 20);
        double startBidScale = 0.14 + 0.014 * Math.min(score.estimatedValue, 18);

        if (score.estimatedValue >= 18) {
            startBidScale += 0.03;
        }

        int maxBid = (int) Math.round(
                score.estimatedValue * maxBidScale * bidBoost * aggression
        );

        int startBid = (int) Math.round(
                score.estimatedValue * startBidScale * bidBoost * aggression
        );

        if (spendingPressure > 0.12) {
            startBid += 2;
            maxBid += 9;
        } else if (spendingPressure > 0.08) {
            startBid += 1;
            maxBid += 5;
        } else if (spendingPressure > 0.04) {
            startBid += 1;
            maxBid += 2;
        }

        if (progress > 0.93 && spentRatio < HARD_SPEND_FLOOR) {
            startBid += 2;
            maxBid += 6;
        } else if (progress > 0.85 && spentRatio < HARD_SPEND_FLOOR) {
            startBid += 1;
            maxBid += 3;
        }

        if (score.estimatedValue >= 22) {
            maxBid += 2;
        }

        if (belowSpendFloor && score.estimatedValue >= 4) {
            maxBid = Math.max(maxBid, score.estimatedValue + 6);
        }

        if (belowSpendFloor && progress > 0.92
                && spentRatio < 0.295
                && score.estimatedValue >= 4) {
            startBid = Math.max(startBid, 2);
            maxBid = Math.max(maxBid, score.estimatedValue + 11);
        }

        if (!belowSpendFloor && score.estimatedValue >= 22) {
            startBid += 1;
            maxBid += 2;
        }

        maxBid = Math.min(42, maxBid);

        if (remainingBudget < totalBudget / 10
                && spentRatio >= 0.34
                && score.estimatedValue < 18) {
            maxBid = Math.max(1, maxBid / 2);
        }

        if (maxBid > remainingBudget) {
            maxBid = (int) remainingBudget;
        }

        if (maxBid <= 0) {
            return BidRange.ZERO;
        }

        startBid = Math.max(1, startBid);

        if (startBid > maxBid) {
            startBid = maxBid;
        }

        return new BidRange(startBid, maxBid);
    }

    // Controls how quickly the bot should spend its budget.
    private static double targetSpend(double progress) {
        if (progress < 0.20) {
            return 0.03;
        }
        if (progress < 0.40) {
            return 0.08;
        }
        if (progress < 0.60) {
            return 0.15;
        }
        if (progress < 0.80) {
            return 0.23;
        }
        if (progress < 0.90) {
            return 0.29;
        }
        if (progress < 0.97) {
            return 0.31;
        }

        return 0.36;
    }

    // Adjusts bidding aggressiveness based on recent score efficiency.
    private static double adjustAggression(
            SummaryData summary,
            double currentAggression,
            long spentBudget,
            long totalBudget
    ) {
        double spentRatio = totalBudget <= 0L ? 0.0 : (double) spentBudget / (double) totalBudget;

        if (summary.spent <= 0L) {
            if (spentRatio < HARD_SPEND_FLOOR) {
                currentAggression += 0.02;
            }

            return clamp(0.86, 1.22, currentAggression);
        }

        double efficiency = (double) summary.points / (double) summary.spent;

        if (efficiency > 0.72) {
            currentAggression += 0.05;
        } else if (efficiency > 0.62) {
            currentAggression += 0.02;
        } else if (efficiency < 0.40) {
            currentAggression -= 0.05;
        } else if (efficiency < 0.50) {
            currentAggression -= 0.02;
        }

        if (spentRatio >= SOFT_SPEND_FLOOR && efficiency < 0.58) {
            currentAggression -= 0.02;
        }

        return clamp(0.86, 1.22, currentAggression);
    }

    // Reads the summary line sent by the harness.
    private static SummaryData parseSummary(String line) {
        String[] parts = line.split("\\s+");

        if (parts.length < 3) {
            return SummaryData.EMPTY;
        }

        try {
            long points = Long.parseLong(parts[1]);
            long spent = Long.parseLong(parts[2]);
            return new SummaryData(points, spent);
        } catch (NumberFormatException e) {
            return SummaryData.EMPTY;
        }
    }

    // Reads the budget from command line arguments.
    private static long readBudget(String[] args) {
        if (args == null || args.length == 0) {
            return DEFAULT_BUDGET;
        }

        try {
            return Math.max(0L, Long.parseLong(args[0]));
        } catch (NumberFormatException e) {
            return DEFAULT_BUDGET;
        }
    }

    // Determines if a line belongs to the harness protocol.
    private static boolean isProtocolLine(String line) {
        return line.length() < 2 || Character.isWhitespace(line.charAt(1));
    }

    // Extracts the winning bid cost from protocol lines.
    private static long extractWinCost(String line) {
        String[] parts = line.split("\\s+");

        if (parts.length < 2) {
            return 0L;
        }

        try {
            return Math.max(0L, Long.parseLong(parts[1]));
        } catch (NumberFormatException e) {
            return 0L;
        }
    }

    // Safely parses a long value.
    private static long parseLong(String value) {
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            return 0L;
        }
    }

    // Converts category text into the matching table index.
    private static int categoryIndex(String value) {
        if (value == null) {
            return -1;
        }

        switch (value) {
            case "Music":
                return 0;
            case "Sports":
                return 1;
            case "Kids":
                return 2;
            case "DIY":
                return 3;
            case "Video Games":
                return 4;
            case "ASMR":
                return 5;
            case "Beauty":
                return 6;
            case "Cooking":
                return 7;
            case "Finance":
                return 8;
            default:
                return -1;
        }
    }

    // Converts age text into the matching table index.
    private static int ageIndex(String value) {
        if (value == null) {
            return -1;
        }

        switch (value) {
            case "13-17":
                return 0;
            case "18-24":
                return 1;
            case "25-34":
                return 2;
            case "35-44":
                return 3;
            case "45-54":
                return 4;
            case "55+":
                return 5;
            default:
                return -1;
        }
    }

    // Returns the estimated age and gender weight for the given category.
    private static double ageCategoryWeight(String age, String gender, int categoryIndex) {
        int ageIndex = ageIndex(age);

        if (ageIndex < 0) {
            return 0.0;
        }

        if ("M".equals(gender)) {
            return AGE_WEIGHT_MALE[ageIndex][categoryIndex];
        }

        return AGE_WEIGHT_FEMALE[ageIndex][categoryIndex];
    }

    // Returns a base value based on the video's view count range.
    private static int baseValueForViews(long viewCount) {
        if (viewCount <= 99L) {
            return 11;
        }
        if (viewCount <= 999L) {
            return 21;
        }
        if (viewCount <= 4999L) {
            return 8;
        }
        if (viewCount <= 24999L) {
            return 32;
        }
        if (viewCount <= 99999L) {
            return 20;
        }
        if (viewCount <= 499999L) {
            return 37;
        }
        if (viewCount <= 1999999L) {
            return 41;
        }
        if (viewCount <= 7999999L) {
            return 22;
        }
        if (viewCount <= 24999999L) {
            return 37;
        }
        if (viewCount <= 74999999L) {
            return 14;
        }

        return 21;
    }

    // Restricts a number so it stays inside the given range.
    private static double clamp(double min, double max, double value) {
        return Math.max(min, Math.min(max, value));
    }

    // Represents one auction opportunity.
    private static class AuctionRound {
        String videoCategory = "";
        long videoViewCount = 0L;
        long videoCommentCount = 0L;
        boolean viewerSubscribed = false;
        String viewerAge = "";
        String viewerGender = "";
        String viewerInterests = "";
    }

    // Represents the estimated value of one auction round.
    private static class RoundScore {
        static final RoundScore EMPTY = new RoundScore(0, -1, false, false, false);

        final int estimatedValue;
        final int financeInterestPosition;
        final boolean financeVideo;
        final boolean directFinance;
        final boolean viewerSubscribed;

        RoundScore(
                int estimatedValue,
                int financeInterestPosition,
                boolean financeVideo,
                boolean directFinance,
                boolean viewerSubscribed
        ) {
            this.estimatedValue = estimatedValue;
            this.financeInterestPosition = financeInterestPosition;
            this.financeVideo = financeVideo;
            this.directFinance = directFinance;
            this.viewerSubscribed = viewerSubscribed;
        }
    }

    // Represents the summary values sent by the harness.
    private static class SummaryData {
        static final SummaryData EMPTY = new SummaryData(0L, 0L);

        final long points;
        final long spent;

        SummaryData(long points, long spent) {
            this.points = points;
            this.spent = spent;
        }
    }

    // Represents the bid range sent to the auction harness.
    private static class BidRange {
        static final BidRange ZERO = new BidRange(0, 0);

        final int startBid;
        final int maxBid;

        BidRange(int startBid, int maxBid) {
            this.startBid = startBid;
            this.maxBid = maxBid;
        }
    }
}